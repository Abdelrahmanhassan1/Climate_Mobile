package com.example.climate_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
